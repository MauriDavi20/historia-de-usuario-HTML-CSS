alert("¡Bienvenido a mi sitio web!")

const saludo = document.getElementById("mensaje").innerText = "hola, bienvenido!"

const parrafo = document.getElementById("texto");
const boton = document.getElementById("btn");


parrafo.textContent = "Haz click en el boton";

boton.addEventListener("click", () =>{
    parrafo.textContent = "Nice, haz hecho click en el boton";
});
